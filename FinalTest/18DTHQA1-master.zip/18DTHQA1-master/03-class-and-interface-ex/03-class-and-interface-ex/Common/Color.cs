﻿using System;
namespace _03_class_and_interface_ex.Common
{
    public enum Color
    {
        Yellow,
        Black,
        White
    }
}
