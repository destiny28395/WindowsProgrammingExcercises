﻿using System;
namespace _04_generic_example.Model
{
    public class Class
    {
        public Class(string name)
        {
            Name = name;
        }

        public string Name { get; set; }

    }
}
