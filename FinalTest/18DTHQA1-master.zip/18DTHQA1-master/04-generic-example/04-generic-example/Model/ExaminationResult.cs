﻿using System;
namespace _04_generic_example.Model
{
    public class ExaminationResult
    {
        public ExaminationResult()
        {
        }
    }
}
