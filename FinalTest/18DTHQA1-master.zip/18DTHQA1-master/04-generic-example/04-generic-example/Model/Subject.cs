﻿using System;
namespace _04_generic_example.Model
{
    public class Subject
    {
        public Subject()
        {
        }
    }
}
