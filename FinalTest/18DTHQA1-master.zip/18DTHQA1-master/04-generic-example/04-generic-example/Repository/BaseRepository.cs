﻿using System.Collections.Generic;

namespace _04_generic_example.Repository
{
    public class BaseRepository
    {

        public BaseRepository()
        {
        }

    }
}
