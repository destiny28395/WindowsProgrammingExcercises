﻿namespace _07_linq {
    public class Result {
        public string Subject { get; set; }

        public int Score { get; set; }
    }
}
