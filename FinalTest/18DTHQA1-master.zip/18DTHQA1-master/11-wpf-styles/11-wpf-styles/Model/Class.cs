﻿

namespace _11_wpf_styles.Model {
    public class Class {

        public Class(string className, int year) {
            ClassName = className;
            Year = year;
        }
        public string ClassName { get; set; }

        public int Year { get; set; }
    }
}
