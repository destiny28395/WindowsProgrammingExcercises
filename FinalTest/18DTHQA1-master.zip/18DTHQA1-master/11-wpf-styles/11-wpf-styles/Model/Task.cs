﻿

namespace _11_wpf_styles.Model {
    public class TodoTask {
        public string TaskName { get; set; }
        public string Description { get; set; }
        public int Priority { get; set; }

        public override string ToString() {
            return TaskName;
        }
    }
}
