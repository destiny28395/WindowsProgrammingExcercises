﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpf_mvvm
{
    public class Class
    {
        public string ClassName { get; set; }

        public int Year { get; set; }
    }
}
